﻿namespace Tesco.ClubcardProducts.MCA.API.Common.Entities.Activation
{
    public enum ActivationRequestStatusEnum
    {
        ClubcardDetailsDoesntMatch,
        ActivationFailed,
        ActivationSuccessful,
        ErrorMessage,
        DuplicateDotcomID,
        CustomerIDalready
    }
}
