﻿namespace Tesco.ClubcardProducts.MCA.API.Common.Entities.Boost
{
    public enum RewardAndPointsEnum
    {
        Reward_Points,
        Statement_Date,
        VoucherValue
    }
}
