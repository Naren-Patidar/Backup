﻿namespace Tesco.ClubcardProducts.MCA.API.Common.Entities.Boost
{

    public enum RewardEnum
    {
        BookingDate,
        TokenDescription,
        ProductStatus,
        TokenValue,
        SupplierTokenCode,
        ValidUntil
    }

}
