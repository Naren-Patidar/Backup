﻿namespace Tesco.ClubcardProducts.MCA.API.Common.Entities
{
    public enum KVPairEnum
    {
        ID,
        Name
    }
}
