﻿namespace Tesco.ClubcardProducts.MCA.API.Common.Entities
{
    public enum OfferDetailsEnum
    {
        OfferID,
        StartDateTime,
        EndDateTime,
        PointsToRewardConversionRate,
        CollectionPeriodNumber
        //OfferName
    }
}
