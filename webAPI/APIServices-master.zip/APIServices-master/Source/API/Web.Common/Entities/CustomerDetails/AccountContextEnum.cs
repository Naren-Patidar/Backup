﻿namespace Tesco.ClubcardProducts.MCA.API.Common.Entities.CustomerDetails
{
    public enum AccountContextEnum
    {
        PromotionCodeExist,
        IsAlternateIDDuplicate,
        ISDuplicate,
    }
}
