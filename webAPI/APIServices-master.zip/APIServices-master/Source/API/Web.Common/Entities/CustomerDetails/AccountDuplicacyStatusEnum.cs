﻿namespace Tesco.ClubcardProducts.MCA.API.Common.Entities.CustomerDetails
{
    public enum AccountDuplicacyStatusEnum
    {
        PromoCodeAlreadyExist,
        IsMainAndAlternateIdUnique,
        None
    }
}
