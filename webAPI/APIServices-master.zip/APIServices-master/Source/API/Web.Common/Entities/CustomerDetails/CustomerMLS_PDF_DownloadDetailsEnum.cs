﻿namespace Tesco.ClubcardProducts.MCA.API.Common.Entities
{
    public enum CustomerMLS_PDF_DownloadDetailsEnum
    {
        PrimaryCustName1,
        PrimaryCustName2,
        PrimaryCustName3,
        PrimaryClubcardID,
        AssociateCustName1,
        AssociateCustName2,
        AssociateCustName3,
        AssociateClubcardID
    }
}
