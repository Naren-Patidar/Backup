﻿namespace Tesco.ClubcardProducts.MCA.API.Common.Entities
{
    public enum ISOLanguageEnum
    {
        ISOLanguageCode, 
        ISOLanguageDescEnglish
    }
}
