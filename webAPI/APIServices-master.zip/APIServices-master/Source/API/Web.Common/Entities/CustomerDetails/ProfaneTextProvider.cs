﻿namespace Tesco.ClubcardProducts.MCA.API.Common.Entities.CustomerDetails
{
    public abstract class ProfaneTextProvider
    {
        public abstract string ProfaneText { get; }
    }
}
