﻿namespace Tesco.ClubcardProducts.MCA.API.Common.Entities
{
    public enum ProvinceEnum
    {
        ProvinceID,
        ProvinceNameEnglish,
        ProvinceNameLocal

    }
}
