﻿namespace Tesco.ClubcardProducts.MCA.API.Common.Entities
{
    public enum RaceEnum
    {
        raceid,
        racedescenglish,
        RaceDescLocal
        
    }
}
