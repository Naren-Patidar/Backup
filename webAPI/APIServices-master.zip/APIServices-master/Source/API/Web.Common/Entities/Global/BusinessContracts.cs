﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tesco.ClubcardProducts.MCA.API.Common.Entities.Global
{
    public enum BusinessContracts
    {
        IVoucher,
        IPoints,
        ICoupons,
        IHome,
        IPersonalDetails
    }
}
