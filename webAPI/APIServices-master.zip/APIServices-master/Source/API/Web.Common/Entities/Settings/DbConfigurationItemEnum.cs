﻿namespace Tesco.ClubcardProducts.MCA.API.Common.Entities.Settings
{
    public enum DbConfigurationItemEnum
    {
        ConfigurationType,
        ConfigurationName,
        ConfigurationValue1,
        ConfigurationValue2,
        IsDeleted
    }
}
