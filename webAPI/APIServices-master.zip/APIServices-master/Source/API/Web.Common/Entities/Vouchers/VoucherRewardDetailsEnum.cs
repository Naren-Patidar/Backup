﻿namespace Tesco.ClubcardProducts.MCA.API.Common.Entities.Vouchers
{
    public static class VoucherRewardDetailsEnum
    {
        public const string RewardIssued = "Reward_Issued";
        public const string RewardUsed = "Reward_Used";
        public const string RewardLeftOver = "Reward_Left_Over";
    }
}
