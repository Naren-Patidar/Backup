﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AutoMapper;
using Tesco.ClubcardProducts.MCA.Web.Common.Models;
using Tesco.ClubcardProducts.MCA.Web.Common.Entities;
using Tesco.ClubcardProducts.MCA.Web.Common.Entities.Common;
using Tesco.ClubcardProducts.MCA.Web.Common.Entities.Vouchers;

namespace Tesco.ClubcardProducts.MCA.Web.Business.BusinessLogics
{
    public class ViewModelProfile : Profile
    {
        /// <summary>
        /// Placeholder for comments on why there is no implementation inside this method.
        /// </summary>
        protected override void Configure()
        {
            
        }
    }
}
