﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tesco.ClubcardProducts.MCA.Web.Business.Contracts
{
   public class IBoostAtTescoBC
    {

    }
}
