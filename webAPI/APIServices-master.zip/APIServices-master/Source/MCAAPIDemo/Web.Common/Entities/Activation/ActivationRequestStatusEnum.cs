﻿namespace Tesco.ClubcardProducts.MCA.Web.Common.Entities.Activation
{
    public enum ActivationRequestStatusEnum
    {
        ClubcardDetailsDoesntMatch,
        ActivationFailed,
        ActivationSuccessful,
        ErrorMessage,
        DuplicateDotcomID,
        CustomerIDalready
    }
}
