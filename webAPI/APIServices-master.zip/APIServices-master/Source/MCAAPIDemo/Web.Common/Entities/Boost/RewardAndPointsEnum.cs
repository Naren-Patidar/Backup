﻿namespace Tesco.ClubcardProducts.MCA.Web.Common.Entities.Boost
{
    public enum RewardAndPointsEnum
    {
        Reward_Points,
        Statement_Date,
        VoucherValue
    }
}
