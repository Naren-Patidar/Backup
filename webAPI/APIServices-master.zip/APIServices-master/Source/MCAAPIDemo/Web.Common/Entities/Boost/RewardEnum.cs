﻿namespace Tesco.ClubcardProducts.MCA.Web.Common.Entities.Boost
{

    public enum RewardEnum
    {
        BookingDate,
        TokenDescription,
        ProductStatus,
        TokenValue,
        SupplierTokenCode,
        ValidUntil
    }

}
