﻿namespace Tesco.ClubcardProducts.MCA.Web.Common.Entities.ChristmasSaver
{
    public static class ChristmasSaverSummaryEnum
    {
        public const string TransactionDateTime = "TransactionDateTime";
        public const string AmountSpent = "AmountSpent";
    }
}
