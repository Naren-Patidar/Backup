﻿namespace Tesco.ClubcardProducts.MCA.Web.Common.Entities
{
    public enum KVPairEnum
    {
        ID,
        Name
    }
}
