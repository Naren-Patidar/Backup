﻿namespace Tesco.ClubcardProducts.MCA.Web.Common.Entities
{
    public enum OfferDetailsEnum
    {
        OfferID,
        StartDateTime,
        EndDateTime,
        PointsToRewardConversionRate,
        CollectionPeriodNumber
        //OfferName
    }
}
