﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tesco.ClubcardProducts.MCA.Web.Common.Entities.Common
{
    public enum StatementTypesEnum
    {
        Reward,
        AirmilesReward,
        XmasSavers,
        BAmilesReward,
        NonReward,
        VirginMilesReward
    }
}
