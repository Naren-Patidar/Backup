﻿namespace Tesco.ClubcardProducts.MCA.Web.Common.Entities.CustomerDetails
{
    public enum AccountContextEnum
    {
        PromotionCodeExist,
        IsAlternateIDDuplicate,
        ISDuplicate,
    }
}
