﻿namespace Tesco.ClubcardProducts.MCA.Web.Common.Entities.CustomerDetails
{
    public enum AccountDuplicacyStatusEnum
    {
        PromoCodeAlreadyExist,
        IsMainAndAlternateIdUnique,
        None
    }
}
