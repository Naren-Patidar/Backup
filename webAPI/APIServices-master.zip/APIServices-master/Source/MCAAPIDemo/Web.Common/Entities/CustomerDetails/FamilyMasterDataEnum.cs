﻿namespace Tesco.ClubcardProducts.MCA.Web.Common.Entities
{
    public static class FamilyMasterDataEnum
    {
        public const string FamilyMemberSeqNo = "FamilyMemberSeqNo";
        public const string DateOfBirth = "DateOfBirth";
        public const string number_of_household_members = "number_of_household_members";
    }
}