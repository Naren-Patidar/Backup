﻿namespace Tesco.ClubcardProducts.MCA.Web.Common.Entities
{
    public enum ISOLanguageEnum
    {
        ISOLanguageCode, 
        ISOLanguageDescEnglish
    }
}
