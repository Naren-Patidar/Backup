﻿namespace Tesco.ClubcardProducts.MCA.Web.Common.Entities.CustomerDetails
{
    public abstract class ProfaneTextProvider
    {
        public abstract string ProfaneText { get; }
    }
}
