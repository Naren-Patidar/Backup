﻿namespace Tesco.ClubcardProducts.MCA.Web.Common.Entities
{
    public enum ProvinceEnum
    {
        ProvinceID,
        ProvinceNameEnglish,
        ProvinceNameLocal

    }
}
