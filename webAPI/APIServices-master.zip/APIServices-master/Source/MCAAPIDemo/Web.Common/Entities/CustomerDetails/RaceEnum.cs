﻿namespace Tesco.ClubcardProducts.MCA.Web.Common.Entities
{
    public enum RaceEnum
    {
        raceid,
        racedescenglish,
        RaceDescLocal
        
    }
}
