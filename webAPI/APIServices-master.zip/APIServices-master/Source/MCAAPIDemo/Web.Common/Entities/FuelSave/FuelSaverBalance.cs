﻿namespace Tesco.ClubcardProducts.MCA.Web.Common.Entities.FuelSave
{
   public class FuelSaverBalance
    {
        public string ExpiryDate { get; set; }
        public string Balance { get; set; }
        public string IsExpired { get; set; }
        public bool SpnError_Visible { get; set; }
        public string CCBodyStylePixels { get; set; }
        public string Width= "width";
    }
}
