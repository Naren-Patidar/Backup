﻿namespace Tesco.ClubcardProducts.MCA.Web.Common.Entities.OrderReplacement
{
    public enum OrderReplacementStatusEnum
    {
        oldOrderExists,
        ClubcardTypeIndicatior,
        noOfDaysLeftToProcess,
        countOrdersPlacedInYear,
        standardCardNumber
    }
}
