﻿namespace Tesco.ClubcardProducts.MCA.Web.Common.Entities.Preferences
{
    public enum BTMediaEnum
    {
        MediaID,
        MediaDescription
    }
}
