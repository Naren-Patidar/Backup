﻿namespace Tesco.ClubcardProducts.MCA.Web.Common.Entities.Settings
{
    public static class ActivationStatusType
    {
        public const char CustomerActivated = 'Y';
        public const char CustomerPending = 'P';
        public const char CustomerNotactivated = 'N';
    }
}
